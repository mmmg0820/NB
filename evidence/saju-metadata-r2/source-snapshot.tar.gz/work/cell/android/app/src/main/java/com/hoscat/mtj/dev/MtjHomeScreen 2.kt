package com.hoscat.mtj.dev

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.hoscat.core.model.SajuChart
import com.mtj.design.MtjBottomActionScaffold
import com.mtj.design.MtjEmptyState
import com.mtj.design.MtjQuietPanel
import com.mtj.design.MtjSectionHeader
import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.CancellationException
import mtj.records.Envelope
import mtj.records.Kind

@Composable
internal fun MtjHomeScreen(chart: SajuChart?, store: RecordStore, onNavigate: (Int) -> Unit) {
    var records by remember { mutableStateOf<List<Envelope>?>(null) }
    var loadError by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    LaunchedEffect(refresh) {
        loadError = false
        try {
            records = store.list().filter { it.kind != Kind.PROFILE }
                .sortedByDescending { it.snapshotAtEpochMillis }.take(3)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            loadError = true
        }
    }
    val date = LocalDate.now(ZoneId.of("Asia/Seoul"))
    MtjBottomActionScaffold(0, onNavigate, actions = {}) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).testTag("mtj-home"),
            contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.inverseSurface,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        Modifier
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.inverseSurface,
                                        Color(0xFF4E2E22),
                                        MaterialTheme.colorScheme.primary,
                                    ),
                                ),
                            )
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            "MTJ",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.inverseOnSurface,
                        )
                        Text(
                            "${date.monthValue}월 ${date.dayOfMonth}일의 사주와 선택",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color(0xFFFFE7B0),
                        )
                        Text(
                            "하루의 흐름, 지금 마음에 남은 질문, 저장한 기록을 한 화면에서 이어봅니다.",
                            color = Color(0xFFF8EBDD),
                        )
                    }
                }
            }
            item {
                MtjQuietPanel(Modifier.testTag("home-today")) {
                    MtjSectionHeader("오늘의 흐름", eyebrow = "사주")
                    if (chart == null) {
                        Text("나의 명식부터 시작하세요.", style = MaterialTheme.typography.titleMedium)
                        Text("등록한 명식이 없습니다. 생년월일을 입력하면 오늘의 기준점이 열립니다.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(onClick = { onNavigate(1) }, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) {
                            Text("내 만세력 추가")
                        }
                    } else {
                        SajuChartDisplay(chart)
                        Text("오늘의 운 흐름은 아직 제공되지 않습니다.", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = { onNavigate(1) }) { Text("명식 살펴보기") }
                    }
                }
            }
            item {
                MtjQuietPanel(Modifier.testTag("home-choice")) {
                    MtjSectionHeader("지금의 선택", eyebrow = "타로")
                    Text("지금 마음에 남은 질문", style = MaterialTheme.typography.titleMedium)
                    Text("카드를 고르고, 나의 선택을 기록하세요.", style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    FilledTonalButton(onClick = { onNavigate(2) }, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) {
                        Text("타로 시작하기")
                    }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().testTag("home-records"), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MtjSectionHeader("최근 기록")
                    when {
                        loadError -> {
                            Text("기록을 불러오지 못했습니다. 저장한 내용은 유지됩니다.")
                            TextButton(onClick = { refresh++ }) { Text("다시 시도") }
                        }
                        records == null -> LinearProgressIndicator(Modifier.fillMaxWidth())
                        records?.isEmpty() == true -> MtjEmptyState(
                            title = "아직 저장한 기록이 없습니다.",
                            body = "명식이나 타로 결과를 저장하면 이곳에서 이어볼 수 있습니다.",
                        )
                    }
                }
            }
            items(records.orEmpty(), key = { it.origin.commonId }) { record ->
                OutlinedCard(onClick = { onNavigate(3) }, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(if (record.kind == Kind.SAJU) "사주" else "타로", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary)
                        Text(record.displayText("title"), style = MaterialTheme.typography.titleSmall)
                        Text("기록 목록에서 보기", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item { TextButton(onClick = { onNavigate(3) }) { Text("모든 기록 보기") } }
        }
    }
}
